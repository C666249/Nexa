#!/usr/bin/env python3
"""Source-level release acceptance checks. CI additionally runs real Gradle compilation."""
from pathlib import Path
import re
import sys
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/com/xingyu/orbitagent'
MANIFEST=ROOT/'app/src/main/AndroidManifest.xml'
FILES={p.name:p.read_text(encoding='utf-8') for p in SRC.glob('*.java')}
errors=[]

def verify(condition, description):
    if not condition: errors.append(description)

verify(len(FILES)>=9, 'expected original + enhanced Java files')
xml=ET.parse(MANIFEST).getroot()
android='{http://schemas.android.com/apk/res/android}'
perms=[x.get(android+'name') for x in xml.findall('uses-permission')]
for permission in ('INTERNET','VIBRATE'):
    verify('android.permission.'+permission in perms,'missing '+permission)
for forbidden in ('READ_SMS','READ_CONTACTS','READ_CALL_LOG','QUERY_ALL_PACKAGES',
                  'READ_MEDIA_AUDIO','MANAGE_EXTERNAL_STORAGE','SYSTEM_ALERT_WINDOW'):
    verify('android.permission.'+forbidden not in perms,'over-permission '+forbidden)
verify(xml.find('application').get(android+'allowBackup')=='false','backup should be disabled')
verify(xml.find('application').get(android+'usesCleartextTraffic')=='false','cleartext must be disabled')
access=ET.parse(ROOT/'app/src/main/res/xml/orbit_accessibility.xml').getroot()
verify(access.get(android+'canTakeScreenshot')=='true','screen capability absent')
verify(access.get(android+'canPerformGestures')=='true','gesture capability absent')
registry=FILES['ToolRegistry.java']
registered=re.findall(r'add\("([a-z_]+)"',registry)
expected={'screen_read','screen_ocr','screen_tap','screen_scroll','screen_input',
          'screen_back','media_now_playing','media_control','open_app','device_status',
          'clipboard_copy','share_text','open_url','lumi_ask_text'}
verify(set(registered)==expected,'registry mismatch expected vs '+str(registered))
verify(len(registered)==len(set(registered)),'duplicate tool name')
engine=FILES['AgnesEngine.java']
verify('tool_call_id' in engine and 'i<calls.length()' in engine, 'incomplete tool result accounting')
verify('AtomicBoolean cancelled' in engine and 'cancel()' in engine,'task cancellation missing')
verify('maxRounds = 7, maxTools = 18' in engine,'limits changed without review')
verify('tool output' not in engine.lower() or '不可信内容' in engine,'prompt injection defense missing')
verify('HttpsURLConnection' not in engine or 'https' in engine,'transport contract')
overlay=FILES['AgentOverlay.java']
verify('TYPE_ACCESSIBILITY_OVERLAY' in overlay,'overlay not accessibility-scoped')
verify('showDeleteZone' in overlay and 'vibrate()' in overlay,'drag-to-delete missing')
verify('CountDownLatch' in overlay and 'approve(' in overlay, 'per-call approval missing')
screen=FILES['ScreenAccessService.java']
verify('node.isPassword()' in screen and 'ACTION_SET_TEXT' in screen,'password-protected input missing')
verify('takeScreenshotOfWindow' in screen and 'takeScreenshot(Display.DEFAULT_DISPLAY' in screen,'screenshot fallback absent')
verify('Blocklist.sensitive' in screen,'screen sensitive-app block missing')
verify((ROOT/'.github/workflows/android-debug.yml').exists(),'cloud build workflow absent')
# Lightweight Java structural check: strip literal strings/comments before balancing braces.
for name,src in FILES.items():
    stripped=re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*.*?\*/|//[^\n]*', '', src, flags=re.S)
    balance=0
    for char in stripped:
        if char=='{':balance+=1
        if char=='}':balance-=1
        if balance<0: errors.append(f'{name}: premature closing brace'); break
    verify(balance==0,f'{name}: brace mismatch {balance}')
if errors:
    print('RELEASE CONTRACT CHECK FAILED')
    for e in errors:print('  - '+e)
    sys.exit(1)
print(f'RELEASE CONTRACT PASS: {len(FILES)} Java files, {len(expected)} tools, '
      f'{len(perms)} Android permissions, verified manifest and workflow')
print('NOTE: Source checks do NOT establish compile success or device compatibility.')
