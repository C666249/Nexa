#!/usr/bin/env python3
"""Static checks that do not pretend to compile Android code."""
import json, re, sys
from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
java = list(root.rglob('*.java'))
assert len(java) >= 8
xml = list(root.rglob('*.xml'))
for path in xml: ET.parse(path)
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
assert 'BIND_ACCESSIBILITY_SERVICE' in manifest
assert 'BIND_NOTIFICATION_LISTENER_SERVICE' in manifest
assert 'QUERY_ALL_PACKAGES' not in manifest
assert 'READ_SMS' not in manifest
assert 'SYSTEM_ALERT_WINDOW' not in manifest
registry = (root / 'app/src/main/java/com/xingyu/orbitagent/ToolRegistry.java').read_text()
actual = re.findall(r'add\("(\w+)"',registry)
assert len(actual) == 8, actual
assert len(set(actual)) == len(actual)
assert 'approval.authorize' in registry
assert 'screen().ocr()' in registry
assert 'new JSONArray(required)' not in registry
engine = (root / 'app/src/main/java/com/xingyu/orbitagent/AgnesEngine.java').read_text()
assert 'tool_calls' in engine and 'MAX_' not in engine
assert 'https://' in engine
assert 'SecureSecretStore' in engine
catalog = json.loads((root/'integrations/tool_catalog.json').read_text())
assert sum(len(v) for v in catalog['namespaces'].values()) == 27
print(f'STATIC SMOKE PASS: {len(java)} Java files, {len(xml)} XML files, {len(actual)} live tools, 27 planned app tools')
print('WARNING: No Android SDK/device build or runtime test was performed by this script.')
