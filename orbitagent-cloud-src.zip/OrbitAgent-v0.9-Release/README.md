# Orbit Agent v0.9.0 · Global Android Agent Preview

> **交付等级：可构建源码 / 未经过云端编译或荣耀 Magic6 Pro 实机验证的 Preview。**
> 不将源码静态检查误写成 Android 编译成功，也不声称音频指纹识曲、Lunaxy/Nexa 私有数据桥接已完成。

## 已实现的功能（14 个真实工具）

| 类别 | 工具 | 功能 |
|---|---|---|
| 屏幕 | `screen_read` | 按次授权读取前台 App 的可访问控件树与 index |
| 屏幕 | `screen_ocr` | Android 11+ 用户授权截图，端侧 ML Kit 中英文 OCR；不上传原始截图 |
| 操作 | `screen_tap` | 点最近 8 秒内的控件快照，检查应用和窗口未改变 |
| 操作 | `screen_scroll` | 上下滑动 |
| 操作 | `screen_input` | 在同一窗口可编辑且非密码节点输入不超过 500 字 |
| 操作 | `screen_back` | Android 返回 |
| 媒体 | `media_now_playing` | 系统 MediaSession 标题、歌手、当前播放状态 |
| 媒体 | `media_control` | 经授权 play/pause/next/previous |
| App | `open_app` | 打开白名单 Lunaxy、Nexa、Lumi、抖音、B站 |
| 设备 | `device_status` | 时间、电量、Android SDK、无障碍连接状态 |
| 内容 | `clipboard_copy` | 经授权复制文字，不读取剪贴板 |
| 内容 | `share_text` | 弹出系统分享选择器，由用户最终操作 |
| 浏览 | `open_url` | 经授权打开 HTTPS 网页，不后台抓取网页 |
| Lumi 专属 | `lumi_ask_text` | 调起 LumiFloat 已有 ACTION_SEND text/plain 接口进行文字学习提问 |

## 核心运行特性

- Agnes AI 通过 OpenAI-compatible `/chat/completions` + `tools` 接入；密钥使用 Android Keystore AES-GCM 加密，配置本地保存。
- 多轮 Agent：最多 7 轮模型请求和 18 次真实工具执行；每轮至多执行 8 个工具；即使超限也为每个 tool_call_id 返回错误结果，避免模型协议崩溃。
- 一个任务只能有一个执行流，支持停止正在处理的任务并取消后续工具。
- 逐次授权：任何屏幕读取、OCR 或状态修改都在本机显示工具名称和参数，用户点“允许一次”才执行，35 秒内无回应则拒绝。
- 全局无障碍悬浮球，轻量展开式聊天、工具运行记录、取消、清除短期上下文；可向下拖到红色删除区域关闭并震动。
- 默认不持久化聊天屏幕内容或截图、不使用无障碍事件被动记录、不申请 Root / Shizuku / 短信 / 通讯录等权限。

## 在手机上部署

1. 使用 Android Studio（JDK 17）打开本文件夹。
2. 首次 Gradle 同步需要联网，Android SDK 35、Gradle Wrapper 8.11.1、Android Gradle Plugin 8.9.2。
3. 构建 `:app:assembleDebug`，然后安装 `app/build/outputs/apk/debug/app-debug.apk`。Android 11（API 30）及以上。
4. 进入 Orbit Agent，保存 API Endpoint、模型名称、Key；先点“测试 Agnes 连接”。默认端点与模型参考 Lunaxy R11，服务当前是否可用需实际测试。
5. 在 Android 系统设置里手动开启 Orbit 的无障碍服务。需要读取 MediaSession 时再开启通知访问。
6. 点“显示悬浮球”；打开 B站或其他 App，点悬浮球即可使用 Agent。
7. 每个敏感工具都必须在弹出的授权框明确确认，不要在支付、登录、银行、验证码或密码等敏感界面运行。

### GitHub Actions 自动构建（无需本地 Android Studio）

将本文件夹**完整内容**上传到你自己的独立 GitHub 仓库根目录，进入 Actions → `Orbit Agent Android Debug APK` → `Run workflow`。成功后从工作流底部 `Artifacts` 下载 `OrbitAgent-v0.9-Debug-APK`，解压得到 APK。若构建失败，先查看构建日志；工作流**配置存在不等于已经构建成功**。

### 安装兼容提醒

- 本应用包名 `com.xingyu.orbitagent`，与三个 Stable 应用不同，不会覆盖它们的本地存档。
- Debug 包只能确保同一个签名证书下覆盖升级。GitHub Actions 每次可能产生不同 Debug 签名；如不匹配，应先**备份 Orbit 本身设置**再卸载，或配置稳定签名。Lunaxy、Nexa、LumiFloat 不受影响。
- 荣耀 MagicOS 可能回收后台无障碍服务；若悬浮球消失需在系统后台运行设置中单独测试。

## 没有完成、不要误认已经完成的能力

1. 抖音/B站任意播放音频抓取及音频指纹识曲，受到 AudioPlaybackCapture 捕获策略及指纹数据源限制。
2. Lunaxy 搜歌、创建歌单和管理队列的**原生内部业务桥接**。目前只有系统 MediaSession 媒体控制和无障碍操作。
3. Nexa 待办/笔记的**原生安全写入接口**。Nexa 当前的 `ACTION_SEND` 在分享流程中主要接收 URI，不是直接新增待办的接口。
4. 跨应用长期记忆、后台主动唤醒、自动多小时任务执行以及 Root/Shizuku 权限。
5. 真实 Android 编译、荣耀设备实机运行、Agnes 官方模型工具协议的端到端验证。

## 源码出处与安全边界

本工程从 v0.1 的独立 Kotlin/Java Android Tools 原型增强而来，未复制 Operit 源代码。参考 [Operit](https://github.com/AAswordman/Operit) 的多等级工具授权架构和 Android 官方权限设计。三个原始 Stable ZIP 未修改。完整限制请看 `docs/安全与验收.md`，自动化检查运行 `python3 tests/release_checks.py`。
