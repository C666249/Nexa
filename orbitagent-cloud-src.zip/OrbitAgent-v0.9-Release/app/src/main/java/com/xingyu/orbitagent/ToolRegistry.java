package com.xingyu.orbitagent;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Locale;

/** All model-accessible capabilities and permission prompts live here. No reflection / arbitrary shell. */
public final class ToolRegistry {
    public interface Executor { JSONObject run(JSONObject args) throws Exception; }
    public interface Approval { boolean authorize(String tool, String detail); }
    private static final class Entry {
        final String name, description, risk;
        final JSONObject params;
        final Executor exec;
        Entry(String name, String description, String risk, JSONObject params, Executor exec) {
            this.name=name; this.description=description; this.risk=risk; this.params=params; this.exec=exec;
        }
    }
    private final LinkedHashMap<String, Entry> entries = new LinkedHashMap<>();
    private final Context context;
    private final Approval approval;
    private final MediaTools media;
    public ToolRegistry(Context context, Approval approval) {
        this.context=context.getApplicationContext(); this.approval=approval;
        media=new MediaTools(context);
        add("screen_read", "读取前台非敏感 App 的界面控件和文字；点击/输入之前需要先读取以获得 index。", "screen",
                schema(new String[][]{}, new String[]{}), args -> screen().readTree());
        add("screen_ocr", "仅按用户请求截图并在设备本地识别中文及英文；发送文字到模型，不发送原始图片。", "screen",
                schema(new String[][]{}, new String[]{}), args -> screen().ocr());
        add("screen_tap", "点击上次 screen_read 返回的 index。快照须有效且前台包名一致。", "write",
                schema(new String[][]{{"index","integer","最新 screen_read 中的 index"}},new String[]{"index"}),
                args -> screen().tap(args.getInt("index")));
        add("screen_scroll", "在当前非敏感 App 页面上下滑动。", "write",
                schema(new String[][]{{"direction","string","down 向下翻页，up 向上翻页"}},new String[]{"direction"}),
                args -> {
                    String d=args.getString("direction");
                    if (!d.equals("down") && !d.equals("up")) return fail("方向只能是 up/down");
                    return screen().scroll(d.equals("down"));
                });
        add("screen_input", "在最新 screen_read 标明 editable=true 的输入框填入用户要求的文字；禁止密码字段。", "write",
                schema(new String[][]{{"index","integer","screen_read 的可编辑节点 index"},
                        {"text","string","待填写内容，最多 500 字"}},new String[]{"index","text"}),
                args -> {
                    String value=args.getString("text");
                    if (value.length()>500) return fail("输入文本不得超过 500 字");
                    return screen().input(args.getInt("index"),value);
                });
        add("screen_back", "执行 Android 返回，关闭当前 App 内页面；不能执行连续多次未批准的操作。", "write",
                schema(new String[][]{},new String[]{}),args -> screen().back());
        add("media_now_playing", "读取 Android MediaSession 提供的歌曲或视频元数据。不会抓取内部音频。", "read",
                schema(new String[][]{},new String[]{}),args -> media.nowPlaying());
        add("media_control", "控制用户指定的媒体会话：play、pause、next、previous。", "write",
                schema(new String[][]{{"package","string","media_now_playing 的 package"},
                        {"action","string","play/pause/next/previous"}},new String[]{"package","action"}),
                args -> media.control(args.getString("action"),args.getString("package")));
        add("open_app", "打开已明确列出的 App：lunaxy、nexa、lumi、douyin、bilibili。", "write",
                schema(new String[][]{{"app","string","lunaxy/nexa/lumi/douyin/bilibili"}},new String[]{"app"}),
                args -> openApp(args.getString("app")));
        add("device_status", "返回手机时间、电池百分比、Android 版本及无障碍状态，不需要额外权限。", "read",
                schema(new String[][]{},new String[]{}), args -> deviceStatus());
        add("clipboard_copy", "经用户确认后把指定文字复制到系统剪贴板，不读取剪贴板。", "write",
                schema(new String[][]{{"text","string","要复制的非敏感文字"}},new String[]{"text"}),
                args -> copy(args.getString("text")));
        add("share_text", "启动系统分享选择器，由用户手动选择目标 App 和确认发送；不自动发送。", "write",
                schema(new String[][]{{"text","string","要分享的文本"}},new String[]{"text"}),
                args -> share(args.getString("text")));
        add("open_url", "在设备默认浏览器打开用户任务相关 HTTPS 网站；不能后台抓取内容。", "write",
                schema(new String[][]{{"url","string","完整 HTTPS URL"}},new String[]{"url"}),
                args -> openUrl(args.getString("url")));
        add("lumi_ask_text", "将文本交给 LumiFloat 已有的分享接收界面，由用户继续确认解题；不绕过原有流程。", "write",
                schema(new String[][]{{"text","string","待交给 LumiFloat 的题目或学习内容"}},new String[]{"text"}),
                args -> lumiAsk(args.getString("text")));
    }
    private void add(String name,String description,String risk,JSONObject params,Executor exec) {
        entries.put(name,new Entry(name,description,risk,params,exec));
    }
    public JSONArray definitions() throws Exception {
        JSONArray array=new JSONArray();
        for (Entry entry:entries.values()) array.put(new JSONObject().put("type","function")
                .put("function",new JSONObject().put("name",entry.name)
                        .put("description",entry.description).put("parameters",entry.params)));
        return array;
    }
    public JSONObject invoke(String name,JSONObject args) {
        Entry entry=entries.get(name);
        if (entry==null) return fail("未知工具："+name);
        try {
            JSONObject safeArgs=args==null?new JSONObject():args;
            if (!"read".equals(entry.risk)) {
                String detail=safeArgs.toString();
                if (detail.length()>300) detail=detail.substring(0,300)+"…";
                if (!approval.authorize(name,detail)) return fail("未获得用户的本次授权");
            }
            JSONObject result=entry.exec.run(safeArgs);
            return result==null?fail("工具没有返回结果"):result;
        } catch(Exception e) { return fail("工具异常："+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage())); }
    }
    private ScreenAccessService screen() throws Exception {
        ScreenAccessService s=ScreenAccessService.active;
        if(s==null) throw new Exception("无障碍服务没有开启，请在 Android 设置中手动打开");
        return s;
    }
    private JSONObject openApp(String app) throws Exception {
        final String pkg;
        switch(app.toLowerCase(Locale.ROOT)) {
            case "lunaxy": pkg="com.xingyu.music"; break;
            case "nexa": pkg="com.nexa.app"; break;
            case "lumi": pkg="com.lumi.floatstudy"; break;
            case "douyin": pkg="com.ss.android.ugc.aweme"; break;
            case "bilibili": pkg="tv.danmaku.bili"; break;
            default: return fail("应用不在允许名单");
        }
        Intent launch=context.getPackageManager().getLaunchIntentForPackage(pkg);
        if(launch==null) return fail("应用未安装或无法获取启动入口："+pkg);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launch);
        return ok().put("package",pkg);
    }
    private JSONObject deviceStatus() throws Exception {
        BatteryManager battery=(BatteryManager)context.getSystemService(Context.BATTERY_SERVICE);
        int pct=battery==null?-1:battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        return ok().put("time",new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(new java.util.Date()))
                .put("battery_percent",pct).put("android_sdk",Build.VERSION.SDK_INT)
                .put("accessibility_enabled",ScreenAccessService.connected());
    }
    private JSONObject copy(String text) throws Exception {
        if (text.length()>4000) return fail("复制长度超过 4000 字");
        ClipboardManager clip=(ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
        if(clip==null) return fail("剪贴板不可用");
        clip.setPrimaryClip(ClipData.newPlainText("Orbit Agent",text));
        return ok().put("characters",text.length());
    }
    private JSONObject share(String text) throws Exception {
        if(text.length()>8000) return fail("分享长度超过 8000 字");
        Intent send=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,text);
        Intent chooser=Intent.createChooser(send,"选择你希望分享的应用");
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(chooser);
        return ok().put("note","已弹出系统分享面板，等待用户完成；并未自动发送");
    }
    private JSONObject openUrl(String raw) throws Exception {
        if(raw.length()>2048) return fail("链接太长");
        Uri uri=Uri.parse(raw);
        if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost()==null || uri.getUserInfo()!=null)
            return fail("只支持合法 HTTPS URL");
        Intent intent=new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return ok().put("url",raw).put("note","已交由系统浏览器打开");
    }
    private JSONObject lumiAsk(String text) throws Exception {
        if(text.isEmpty() || text.length()>7000) return fail("题目内容长度需要 1 到 7000 字");
        Intent send=new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT,text).setPackage("com.lumi.floatstudy")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if(send.resolveActivity(context.getPackageManager())==null)
            return fail("LumiFloat 未安装，或当前版本不支持文字分享");
        context.startActivity(send);
        return ok().put("destination","LumiFloat")
                .put("note","已启动 LumiFloat 的原生文本接收界面；用户需在应用内继续确认");
    }
    private static JSONObject schema(String[][] items,String[] required) {
        JSONObject props=new JSONObject(); JSONArray needed=new JSONArray();
        try {
            for(String[] field:items) props.put(field[0],new JSONObject().put("type",field[1]).put("description",field[2]));
            for(String key:required) needed.put(key);
            return new JSONObject().put("type","object").put("properties",props)
                    .put("required",needed).put("additionalProperties",false);
        } catch(Exception e) {throw new IllegalStateException(e);}
    }
    private static JSONObject ok() throws Exception {return new JSONObject().put("success",true);}
    public static JSONObject fail(String detail) {
        try{return new JSONObject().put("success",false).put("error",detail);}catch(Exception e){return new JSONObject();}
    }
}
