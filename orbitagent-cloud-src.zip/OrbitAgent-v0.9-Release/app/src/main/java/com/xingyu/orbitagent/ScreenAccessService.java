package com.xingyu.orbitagent;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Bundle;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityWindowInfo;
import android.view.accessibility.AccessibilityNodeInfo;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.TextRecognizer;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** On-demand screen access only; no accessibility-event logging or background monitoring. */
public final class ScreenAccessService extends AccessibilityService {
    static volatile ScreenAccessService active;
    private AgentOverlay overlay;
    void runOnMain(Runnable r) { main.post(r); }
    public void showOverlay() { runOnMain(() -> { if (overlay == null) overlay = new AgentOverlay(this); }); }
    public void hideOverlay() { runOnMain(() -> { if (overlay != null) { overlay.close(); overlay = null; } }); }
    private AccessibilityWindowInfo targetWindow() {
        AccessibilityWindowInfo selected = null;
        for (AccessibilityWindowInfo window : getWindows()) {
            if (window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
            AccessibilityNodeInfo node = window.getRoot();
            if (node == null) continue;
            String pkg = trimmed(node.getPackageName(),120);
            node.recycle();
            if (pkg.equals(getPackageName())) continue;
            if (window.isActive() || window.isFocused()) return window;
            if (selected == null) selected = window;
        }
        return selected;
    }
    private AccessibilityNodeInfo targetRoot() {
        AccessibilityWindowInfo target = targetWindow();
        return target == null ? getRootInActiveWindow() : target.getRoot();
    }
    private int targetWindowId() {
        AccessibilityWindowInfo target = targetWindow();
        return target == null ? -1 : target.getId();
    }
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile String snapshotPackage = "";
    private volatile long snapshotTime = 0L;
    private volatile List<Rect> snapshotBounds = new ArrayList<>();
    private volatile List<Boolean> snapshotEditable = new ArrayList<>();
    private volatile int snapshotWindowId = -1;

    public static boolean connected() { return active != null; }
    @Override protected void onServiceConnected() {
        super.onServiceConnected(); active = this;
        if (getSharedPreferences("orbit_config",MODE_PRIVATE).getBoolean("bubble",false)) showOverlay();
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* intentionally NO passive logging */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { hideOverlay(); if (active == this) active = null; super.onDestroy(); }

    private static JSONObject error(String message) throws Exception {
        return new JSONObject().put("success", false).put("error", message);
    }
    private static String trimmed(CharSequence s, int limit) {
        if (s == null) return "";
        String x = s.toString().replace('\n', ' ').replace('\r',' ').trim();
        return x.length() <= limit ? x : x.substring(0, limit);
    }
    private static JSONObject nodeInfo(AccessibilityNodeInfo node, int index, Rect bounds) throws Exception {
        boolean secret = node.isPassword();
        JSONObject o = new JSONObject();
        o.put("index", index).put("class", trimmed(node.getClassName(), 100));
        o.put("text", secret ? "[protected]" : trimmed(node.getText(), 180));
        o.put("description", secret ? "[protected]" : trimmed(node.getContentDescription(), 180));
        o.put("clickable", node.isClickable()).put("editable", node.isEditable() && !secret);
        o.put("bounds", new JSONArray().put(bounds.left).put(bounds.top).put(bounds.right).put(bounds.bottom));
        return o;
    }
    private void walk(AccessibilityNodeInfo node, JSONArray out, List<Rect> bounds, List<Boolean> editable, int depth) throws Exception {
        if (node == null || out.length() >= 95 || depth > 14) return;
        Rect box = new Rect(); node.getBoundsInScreen(box);
        if (node.isVisibleToUser() && !box.isEmpty()) {
            int index = bounds.size(); bounds.add(new Rect(box));
            editable.add(node.isEditable() && !node.isPassword());
            String t = trimmed(node.getText(), 5), d = trimmed(node.getContentDescription(), 5);
            if (!t.isEmpty() || !d.isEmpty() || node.isClickable() || node.isEditable()) {
                out.put(nodeInfo(node, index, box));
            }
        }
        for (int i = 0; i < node.getChildCount() && out.length() < 95; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { try { walk(child, out, bounds, editable, depth + 1); } finally { child.recycle(); } }
        }
    }
    private <T> T onUi(java.util.concurrent.Callable<T> action, long ms) throws Exception {
        if (Looper.myLooper() == Looper.getMainLooper()) return action.call();
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<T> result = new AtomicReference<>();
        AtomicReference<Exception> fault = new AtomicReference<>();
        main.post(() -> { try { result.set(action.call()); } catch (Exception e) { fault.set(e); } finally { latch.countDown(); } });
        if (!latch.await(ms, TimeUnit.MILLISECONDS)) throw new Exception("系统界面读取超时");
        if (fault.get() != null) throw fault.get();
        return result.get();
    }
    public JSONObject readTree() throws Exception {
        return onUi(() -> {
            AccessibilityNodeInfo root = targetRoot();
            if (root == null) return error("系统未提供可读取的界面节点，请尝试 OCR");
            try {
                String pkg = trimmed(root.getPackageName(), 120);
                if (pkg.equals(getPackageName())) return error("当前是 Agent 自己的界面，请切换到目标 App 后再读取");
                if (Blocklist.sensitive(pkg)) return error("当前为敏感应用，禁止读取");
                JSONArray array = new JSONArray(); List<Rect> bounds = new ArrayList<>();
                List<Boolean> editable = new ArrayList<>();
                walk(root, array, bounds, editable, 0);
                snapshotPackage = pkg; snapshotBounds = bounds; snapshotEditable = editable;
                snapshotWindowId = root.getWindowId(); snapshotTime = android.os.SystemClock.elapsedRealtime();
                return new JSONObject().put("success", true).put("package", pkg).put("nodes", array)
                        .put("note", "仅当前前台可访问节点，序号8秒内有效；密码字段已屏蔽");
            } finally { root.recycle(); }
        }, 5000);
    }
    public JSONObject tap(int index) throws Exception {
        return onUi(() -> {
            if (android.os.SystemClock.elapsedRealtime() - snapshotTime > 8000) return error("界面快照已过期，请先重新读取");
            AccessibilityNodeInfo root = targetRoot();
            if (root == null) return error("目标页面已变化，请重新读取");
            try {
                String pkg = trimmed(root.getPackageName(), 120);
                if (!pkg.equals(snapshotPackage) || Blocklist.sensitive(pkg) || root.getWindowId()!=snapshotWindowId)
                    return error("前台应用或窗口已变化，禁止误触");
                List<Rect> nodes = snapshotBounds;
                if (index < 0 || index >= nodes.size()) return error("无效的节点序号");
                Rect b = nodes.get(index);
                if (b.isEmpty()) return error("节点已隐藏");
                Path path = new Path(); path.moveTo(b.centerX(), b.centerY());
                if (overlay != null) overlay.pauseBriefly(600);
                boolean accepted = dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(path, 0, 90)).build(), null, null);
                snapshotTime = 0;
                return new JSONObject().put("success", accepted).put("target_package", pkg).put("index", index);
            } finally { root.recycle(); }
        }, 5000);
    }
    // Attempt ACTION_SET_TEXT only on a still-matching, visibly editable node.
    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo node, Rect wanted, int depth) {
        if (node == null || depth > 18) return null;
        Rect current = new Rect(); node.getBoundsInScreen(current);
        if (node.isVisibleToUser() && current.equals(wanted) && node.isEditable() && !node.isPassword()) {
            return AccessibilityNodeInfo.obtain(node);
        }
        for(int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo child=node.getChild(i);
            if(child==null) continue;
            try {
                AccessibilityNodeInfo match=findNode(child,wanted,depth+1);
                if(match!=null) return match;
            } finally { child.recycle(); }
        }
        return null;
    }
    public JSONObject input(int index, String content) throws Exception {
        return onUi(() -> {
            if(android.os.SystemClock.elapsedRealtime()-snapshotTime>8000)
                return error("快照已过期，请重新 screen_read");
            AccessibilityNodeInfo root=targetRoot();
            if(root==null) return error("没有前台应用窗口");
            try {
                String pkg=trimmed(root.getPackageName(),120);
                if(Blocklist.sensitive(pkg) || !pkg.equals(snapshotPackage) || root.getWindowId()!=snapshotWindowId)
                    return error("前台窗口变化，已拒绝输入");
                if(index<0 || index>=snapshotBounds.size() || !snapshotEditable.get(index))
                    return error("指定节点不是可编辑的安全输入框");
                AccessibilityNodeInfo field=findNode(root,snapshotBounds.get(index),0);
                if(field==null) return error("输入框已失效或被遮挡");
                try {
                    Bundle args=new Bundle(); args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,content);
                    boolean done=field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args);
                    snapshotTime=0;
                    return new JSONObject().put("success",done).put("package",pkg)
                            .put("characters",content.length()).put("note",done?"已提交到输入控件":"控件不支持设置文本");
                } finally {field.recycle();}
            } finally {root.recycle();}
        },5000);
    }
    public JSONObject back() throws Exception {
        return onUi(() -> {
            AccessibilityNodeInfo root=targetRoot();
            if(root==null) return error("没有前台应用");
            try {
                if(Blocklist.sensitive(trimmed(root.getPackageName(),120))) return error("当前应用禁止自动操作");
                snapshotTime=0;
                return new JSONObject().put("success",performGlobalAction(GLOBAL_ACTION_BACK));
            } finally {root.recycle();}
        },3000);
    }
    public JSONObject scroll(boolean down) throws Exception {
        return onUi(() -> {
            AccessibilityNodeInfo root = targetRoot();
            if (root == null) return error("没有前台窗口");
            try {
                String pkg = trimmed(root.getPackageName(), 120);
                if (Blocklist.sensitive(pkg) || pkg.equals(getPackageName())) return error("当前窗口禁止操作");
                android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
                float x = dm.widthPixels * 0.5f;
                float sy = dm.heightPixels * (down ? 0.75f : 0.32f);
                float ey = dm.heightPixels * (down ? 0.32f : 0.75f);
                Path p = new Path(); p.moveTo(x, sy); p.lineTo(x, ey);
                if (overlay != null) overlay.pauseBriefly(800);
                boolean accepted = dispatchGesture(new GestureDescription.Builder()
                        .addStroke(new GestureDescription.StrokeDescription(p, 0, 400)).build(), null, null);
                snapshotTime = 0;
                return new JSONObject().put("success", accepted).put("direction", down ? "down" : "up");
            } finally { root.recycle(); }
        }, 5000);
    }
    public JSONObject ocr() throws Exception {
        if (android.os.Build.VERSION.SDK_INT < 30) return error("Android 11 以下未启用此截图路径");
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<JSONObject> outcome = new AtomicReference<>();
        main.post(() -> {
            try {
                AccessibilityNodeInfo root = targetRoot();
                String pkg = root == null ? "" : trimmed(root.getPackageName(), 120);
                if (root != null) root.recycle();
                if (Blocklist.sensitive(pkg) || pkg.equals(getPackageName())) {
                    outcome.set(error("当前是敏感/Agent 页面，不发送 OCR")); latch.countDown(); return;
                }
                TakeScreenshotCallback callback = new TakeScreenshotCallback() {
                    @Override public void onSuccess(ScreenshotResult screenshot) {
                        android.hardware.HardwareBuffer buffer = screenshot.getHardwareBuffer();
                        try {
                            Bitmap hardware = Bitmap.wrapHardwareBuffer(buffer, screenshot.getColorSpace());
                            if (hardware == null) throw new Exception("无法获得 Bitmap");
                            Bitmap software = hardware.copy(Bitmap.Config.ARGB_8888, false);
                            hardware.recycle();
                            if (software == null) throw new Exception("无法复制 Bitmap");
                            TextRecognizer recognizer = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
                            recognizer.process(InputImage.fromBitmap(software, 0))
                                .addOnSuccessListener(result -> {
                                    try { String s = result.getText(); outcome.set(new JSONObject().put("success", true)
                                            .put("package", pkg).put("ocr_text", s.length() > 6500 ? s.substring(0,6500) : s)); }
                                    catch (Exception e) { outcome.set(new JSONObject()); }
                                }).addOnFailureListener(e -> {
                                    try { outcome.set(error("OCR 失败: " + e.getMessage())); } catch (Exception ignored) { }
                                }).addOnCompleteListener(result -> { recognizer.close(); software.recycle(); latch.countDown(); });
                        } catch (Exception e) {
                            try { outcome.set(error("截图失败: " + e.getMessage())); } catch (Exception ignored) { }
                            latch.countDown();
                        } finally { buffer.close(); }
                    }
                    @Override public void onFailure(int errorCode) {
                        try { outcome.set(error("截图不可用，代码=" + errorCode)); } catch (Exception ignored) { }
                        latch.countDown();
                    }
                };
                int targetId = targetWindowId();
                if (android.os.Build.VERSION.SDK_INT >= 34 && targetId >= 0) {
                    takeScreenshotOfWindow(targetId, getMainExecutor(), callback);
                } else {
                    // Older devices cannot exclude our overlay: temporarily hide it during capture.
                    if (overlay != null) overlay.pauseBriefly(950);
                    main.postDelayed(() -> takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), callback), 160);
                }
            } catch (Exception e) {
                try { outcome.set(error(e.toString())); } catch (Exception ignored) { }
                latch.countDown();
            }
        });
        if (!latch.await(12, TimeUnit.SECONDS)) return error("OCR 超时");
        JSONObject ret = outcome.get();
        return ret == null ? error("OCR 没有返回结果") : ret;
    }
}
