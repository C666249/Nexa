package com.xingyu.orbitagent;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Native no-WebView overlay. The small bubble can be dragged to a red bottom disposal zone. */
public final class AgentOverlay {
    private final ScreenAccessService service;
    private final WindowManager wm;
    private final LinearLayout root;
    private final LinearLayout body;
    private final TextView bubble, trace, approvalText, status, deleteZone, heading, collapse;
    private final LinearLayout approvalButtons;
    private final EditText prompt;
    private final Button send, stop;
    private final ScrollView scroll;
    private WindowManager.LayoutParams params;
    private WindowManager.LayoutParams deleteParams;
    private final AgnesEngine engine;
    private volatile CountDownLatch approvalLatch;
    private volatile AtomicBoolean approvalChoice;
    private boolean expanded=false;
    private boolean dragging=false;
    private boolean nearDelete=false;
    private boolean destroyed=false;
    private float downX,downY;
    private int originX, originY;
    private int width, height;
    private long touchDownTime;
    private final int cyan=0xFF8CDAE8;
    public AgentOverlay(ScreenAccessService service) {
        this.service=service;
        wm=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
        width=service.getResources().getDisplayMetrics().widthPixels;
        height=service.getResources().getDisplayMetrics().heightPixels;
        int margin=dp(12);
        root=new LinearLayout(service); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(9),dp(9),dp(9),dp(9));
        root.setBackground(panelBackground());
        root.setElevation(dp(18));
        bubble=new TextView(service); bubble.setText("✦"); bubble.setTextSize(26);
        bubble.setTypeface(Typeface.DEFAULT,Typeface.BOLD); bubble.setTextColor(0xFFF0FCFF);
        bubble.setGravity(Gravity.CENTER); bubble.setBackground(round(0xFF1C657B,26));
        LinearLayout header=new LinearLayout(service); header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.addView(bubble,new LinearLayout.LayoutParams(dp(48),dp(48)));
        heading=new TextView(service);
        heading.setText("  Orbit  /  Agent"); heading.setTextSize(16);
        heading.setTextColor(0xFFF1F7FF); heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        header.addView(heading,new LinearLayout.LayoutParams(0,dp(46),1));
        collapse=new TextView(service); collapse.setText("−"); collapse.setTextSize(27);
        collapse.setTextColor(0xFFB2C3D4); collapse.setGravity(Gravity.CENTER);
        header.addView(collapse,new LinearLayout.LayoutParams(dp(40),dp(46)));
        root.addView(header);
        body=new LinearLayout(service); body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(6),dp(7),dp(6),dp(4)); root.addView(body);
        status=new TextView(service); status.setText("●  已就绪  ·  只在你请求时读取屏幕");
        status.setTextSize(11); status.setTextColor(cyan);
        status.setPadding(dp(2),dp(2),0,dp(8)); body.addView(status);
        scroll=new ScrollView(service);
        scroll.setFillViewport(false); scroll.setVerticalScrollBarEnabled(false);
        trace=new TextView(service); trace.setTextSize(13); trace.setTextColor(0xFFE1ECF9);
        trace.setText("欢迎使用 Orbit。\n你可以说：看看当前屏幕、打开 B站、现在播放什么歌。\n\n所有屏幕读取和操作都需你确认。");
        trace.setTextIsSelectable(true); trace.setLineSpacing(dp(4),1.0f);
        scroll.addView(trace);
        body.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(278),(int)(height*.33f))));
        prompt=new EditText(service); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(0xFF8EABBE);
        prompt.setHint("说点什么…"); prompt.setTextSize(14); prompt.setMinLines(1);prompt.setMaxLines(3);
        prompt.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE |
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        prompt.setBackground(round(0xFF25394C,15)); prompt.setPadding(dp(13),dp(7),dp(10),dp(7));
        LinearLayout.LayoutParams editor=new LinearLayout.LayoutParams(-1,dp(63));editor.topMargin=dp(10);
        body.addView(prompt,editor);
        LinearLayout toolbar=new LinearLayout(service); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        send=button("✦ 发送",0xFF37758A); stop=button("停止",0xFF714B59);
        Button clear=button("清除上下文",0xFF34475D);
        toolbar.addView(send,new LinearLayout.LayoutParams(0,dp(42),1));
        toolbar.addView(stop,new LinearLayout.LayoutParams(0,dp(42),.72f));
        toolbar.addView(clear,new LinearLayout.LayoutParams(0,dp(42),1.05f));
        body.addView(toolbar); stop.setEnabled(false); stop.setAlpha(.5f);
        approvalText=new TextView(service); approvalText.setTextSize(12);
        approvalText.setTextColor(0xFFFFD7AD); approvalText.setPadding(dp(5),dp(5),dp(5),dp(5));
        body.addView(approvalText);
        approvalButtons=new LinearLayout(service);
        Button yes=button("允许一次",0xFF2A806F);Button no=button("拒绝",0xFF78474D);
        approvalButtons.addView(yes,new LinearLayout.LayoutParams(0,dp(42),1));
        approvalButtons.addView(no,new LinearLayout.LayoutParams(0,dp(42),1));
        body.addView(approvalButtons);approvalButtons.setVisibility(View.GONE);
        yes.setOnClickListener(v->resolve(true)); no.setOnClickListener(v->resolve(false));
        Button settings=button("设置 / 权限",0xFF34475D); settings.setTextSize(11);
        settings.setOnClickListener(v->{
            android.content.Intent intent=new android.content.Intent(service,MainActivity.class);
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            service.startActivity(intent);
        });
        body.addView(settings,new LinearLayout.LayoutParams(-1,dp(37)));
        engine=new AgnesEngine(service,new ToolRegistry(service,this::approve));
        send.setOnClickListener(v->send());
        stop.setOnClickListener(v->{engine.cancel();resolve(false);status.setText("■  正在停止…");});
        clear.setOnClickListener(v->{engine.clearMemory();log("已清除当前会话的短期上下文");});
        bubble.setOnClickListener(v->setExpanded(!expanded));
        bubble.setOnTouchListener((v,event)->handleBubble(event));
        collapse.setOnClickListener(v->setExpanded(false));
        deleteZone=new TextView(service);deleteZone.setText("拖动到这里关闭悬浮球  ×");
        deleteZone.setTextColor(0xFFF5ECED);deleteZone.setTextSize(14);
        deleteZone.setGravity(Gravity.CENTER);deleteZone.setBackground(round(0xDD8A303B,24));
        params=new WindowManager.LayoutParams(dp(66),WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.LEFT;
        params.x=width-dp(82);params.y=Math.min(dp(175),height/3);
        wm.addView(root,params); setExpanded(false);
    }
    private void send() {
        String request=prompt.getText().toString().trim();
        if(request.isEmpty()) return;
        if(engine.busy()) {log("当前任务尚未结束；可点击停止");return;}
        prompt.setText("");
        log("你 · "+request);
        setBusy(true);
        if(!engine.run(request,new AgnesEngine.Reporter(){
            public void log(String message){AgentOverlay.this.log(message);}
            public void finished(){service.runOnMain(()->setBusy(false));}
        })) setBusy(false);
    }
    private void setBusy(boolean busy) {
        status.setText(busy?"◌  Agnes 正在处理 · 工具过程实时显示":"●  空闲 ·  可以继续提问");
        stop.setEnabled(busy);stop.setAlpha(busy?1f:.5f);
        send.setEnabled(!busy);send.setAlpha(busy?.5f:1f);
    }
    private GradientDrawable panelBackground() {
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xF71A293B,0xF71A2637,0xF7212E43});
        bg.setCornerRadius(dp(25));bg.setStroke(dp(1),0x665F92AB);return bg;
    }
    private GradientDrawable round(int color,int radius) {
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;
    }
    private Button button(String label,int bg) {
        Button b=new Button(service);b.setAllCaps(false);b.setText(label);b.setTextSize(12);
        b.setTextColor(0xFFEAF6FF);b.setBackgroundTintList(ColorStateList.valueOf(bg));
        b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(0,0,0,0);return b;
    }
    private int dp(float x){return Math.round(x*service.getResources().getDisplayMetrics().density);}
    public void setExpanded(boolean on) {
        if(destroyed)return;
        expanded=on; body.setVisibility(on?View.VISIBLE:View.GONE);
        heading.setVisibility(on?View.VISIBLE:View.GONE);
        collapse.setVisibility(on?View.VISIBLE:View.GONE);
        root.setPadding(on?dp(9):dp(9),on?dp(9):dp(9),on?dp(9):dp(9),on?dp(9):dp(9));
        params.width=on?Math.min(dp(365),width-dp(18)):dp(66);
        params.height=WindowManager.LayoutParams.WRAP_CONTENT;
        if(on){params.x=Math.min(params.x,Math.max(0,width-params.width-dp(8)));
            params.y=Math.min(params.y,Math.max(0,height-(int)Math.min(dp(590),height*.78f)));}
        params.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
                (on?0:WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        try{wm.updateViewLayout(root,params);}catch(Exception ignored){}
    }
    private boolean handleBubble(MotionEvent event) {
        if(expanded) return false;
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX=event.getRawX();downY=event.getRawY();
                originX=params.x;originY=params.y;dragging=false;touchDownTime=System.currentTimeMillis();return true;
            case MotionEvent.ACTION_MOVE:
                float dx=event.getRawX()-downX,dy=event.getRawY()-downY;
                if(Math.abs(dx)+Math.abs(dy)>dp(9))dragging=true;
                if(dragging) {
                    params.x=Math.max(0,Math.min(width-dp(66),originX+Math.round(dx)));
                    params.y=Math.max(0,Math.min(height-dp(75),originY+Math.round(dy)));
                    try{wm.updateViewLayout(root,params);}catch(Exception ignored){}
                    showDeleteZone(true);
                    boolean close=params.y>height-dp(175);
                    if(close!=nearDelete) {
                        nearDelete=close;deleteZone.setBackground(round(close?0xF5C03548:0xDD8A303B,24));
                        if(close) vibrate();
                    }
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                showDeleteZone(false);
                if(dragging&&nearDelete) {
                    service.getSharedPreferences("orbit_config",Context.MODE_PRIVATE).edit().putBoolean("bubble",false).apply();
                    service.hideOverlay();return true;
                }
                if(!dragging) setExpanded(true);
                dragging=false;nearDelete=false;return true;
        }
        return false;
    }
    private void vibrate() {
        try {
            Vibrator vib=(Vibrator)service.getSystemService(Context.VIBRATOR_SERVICE);
            if(vib!=null&&vib.hasVibrator())vib.vibrate(VibrationEffect.createOneShot(32,VibrationEffect.DEFAULT_AMPLITUDE));
        } catch(Exception ignored){}
    }
    private void showDeleteZone(boolean show) {
        try {
            if(show&&deleteParams==null) {
                deleteParams=new WindowManager.LayoutParams(Math.min(width-dp(25),dp(345)),dp(69),
                        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        PixelFormat.TRANSLUCENT);
                deleteParams.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;
                deleteParams.y=dp(40);wm.addView(deleteZone,deleteParams);
            } else if(!show&&deleteParams!=null){wm.removeView(deleteZone);deleteParams=null;}
        }catch(Exception ignored){}
    }
    public void log(String text) {
        service.runOnMain(()->{
            if(destroyed)return;
            String original=trace.getText().toString();
            String message=original+"\n\n"+text;
            if(message.length()>10500)message="…\n"+message.substring(message.length()-10000);
            trace.setText(message);scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
        });
    }
    public boolean approve(String tool,String summary) {
        if(destroyed)return false;
        CountDownLatch latch=new CountDownLatch(1);
        AtomicBoolean choice=new AtomicBoolean(false);
        approvalLatch=latch;approvalChoice=choice;
        service.runOnMain(()->{
            if(destroyed){latch.countDown();return;}
            setExpanded(true);
            approvalText.setText("请求本次授权 · "+tool+"\n"+summary);
            approvalButtons.setVisibility(View.VISIBLE);
        });
        try{latch.await(35,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        service.runOnMain(()->{
            approvalText.setText("");approvalButtons.setVisibility(View.GONE);
        });
        approvalLatch=null;approvalChoice=null;
        return choice.get();
    }
    private void resolve(boolean value) {
        AtomicBoolean choice=approvalChoice;CountDownLatch latch=approvalLatch;
        if(choice!=null&&latch!=null){choice.set(value);latch.countDown();}
    }
    void pauseBriefly(long ms) {
        root.setAlpha(0f);
        root.postDelayed(()->{if(!destroyed)root.setAlpha(1f);},ms);
    }
    public void close() {
        destroyed=true;engine.cancel();resolve(false);showDeleteZone(false);
        try{wm.removeView(root);}catch(Exception ignored){}
    }
}
