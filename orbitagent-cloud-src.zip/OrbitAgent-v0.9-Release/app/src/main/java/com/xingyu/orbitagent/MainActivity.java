package com.xingyu.orbitagent;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Setup, diagnostics and permissions. This Activity does not read other apps or request auto-grants. */
public final class MainActivity extends Activity {
    private EditText endpoint, model, token;
    private TextView connectivity, permissions;
    private AgnesEngine diagnostics;
    private final int white=0xFFF2F7FF,muted=0xFFADBED0,accent=0xFF8CDAE8;
    private SharedPreferences pref(){return getSharedPreferences("orbit_config",MODE_PRIVATE);}
    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF101C2B);
        getWindow().setNavigationBarColor(0xFF132235);
        ScrollView scroller=new ScrollView(this);scroller.setFillViewport(true);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24),dp(38),dp(24),dp(36));
        GradientDrawable backdrop=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF101D2C,0xFF1C2F41,0xFF142334});
        page.setBackground(backdrop);
        scroller.addView(page);setContentView(scroller);
        TextView symbol=label("✦",40,accent);symbol.setTypeface(Typeface.DEFAULT,Typeface.BOLD);page.addView(symbol);
        TextView title=label("Orbit Agent",30,white);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);page.addView(title);
        page.addView(label("GLOBAL ANDROID ASSISTANT  /  0.9 PREVIEW",11,accent));
        space(page,12);
        page.addView(label("轻量全局助手 · Agnes AI 负责思考\nAndroid 原生工具负责执行，所有屏幕操作由你授权。",14,muted));
        space(page,22);
        page.addView(section("01   模型连接"));
        endpoint=input("Agnes API 地址",pref().getString("endpoint","https://apihub.agnes-ai.com/v1"),false);
        model=input("模型名",pref().getString("model","agnes-3.0-flash"),false);
        token=input("API Key（仅在你需要更新时填写）","",true);
        page.addView(endpoint);space(page,8);page.addView(model);space(page,8);page.addView(token);
        space(page,9);
        Button save=button("保存设置",0xFF377A8D);page.addView(save);
        save.setOnClickListener(v->save());
        Button test=button("测试 Agnes 连接",0xFF354C61);page.addView(test);
        connectivity=label("尚未运行连接测试。",12,muted);page.addView(connectivity);
        test.setOnClickListener(v->{
            if(!save())return;
            connectivity.setText("◌ 正在连接 Agnes…");test.setEnabled(false);
            diagnostics=new AgnesEngine(this,new ToolRegistry(this,(name,args)->false));
            diagnostics.run("请只回复一句简短的问候，不需要调用工具。",new AgnesEngine.Reporter(){
                public void log(String line){runOnUiThread(()->connectivity.setText(line));}
                public void finished(){runOnUiThread(()->test.setEnabled(true));}
            });
        });
        space(page,22);
        page.addView(section("02   Android 权限"));
        page.addView(label("无障碍用于按需读取、点击和截图；通知访问用于媒体会话。授权都需要你手动打开。",12,muted));
        permissions=label("",12,accent);page.addView(permissions);
        Button a=button("打开无障碍设置",0xFF354C61);page.addView(a);
        a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button n=button("打开通知访问设置",0xFF354C61);page.addView(n);
        n.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        space(page,20);
        page.addView(section("03   全局悬浮面板"));
        page.addView(label("在其他 App 打开 Orbit；向下拖动悬浮球至红色区域可关闭。展开面板可随时终止任务。",12,muted));
        Button show=button("✦ 显示悬浮球",0xFF2F7A79);page.addView(show);
        show.setOnClickListener(v->{
            ScreenAccessService service=ScreenAccessService.active;
            if(service==null){connectivity.setText("请先在系统设置中开启无障碍服务");return;}
            pref().edit().putBoolean("bubble",true).apply();service.showOverlay();refreshStatus();
        });
        Button hide=button("隐藏悬浮球",0xFF584451);page.addView(hide);
        hide.setOnClickListener(v->{pref().edit().putBoolean("bubble",false).apply();
            if(ScreenAccessService.active!=null)ScreenAccessService.active.hideOverlay();refreshStatus();});
        space(page,22);
        page.addView(section("隐私与能力边界"));
        page.addView(label("• 截图由 ML Kit 在设备本地 OCR，原始图片不发送到 Agnes；OCR 文字和工具结果会发送给所配模型。\n"+
                "• 不读取其他 App 私有数据库；Lunaxy、Nexa、LumiFloat 专属数据桥接尚未安装。\n"+
                "• 不具备抖音/B站任意内部音频捕获及音频指纹识曲。\n"+
                "• 所有点击、输入、分享及屏幕读取默认每次确认；拒绝可停止操作。\n"+
                "• API Key 使用 Android Keystore 加密存储；仅在需要联网请求时读取。",12,muted));
    }
    @Override protected void onResume(){super.onResume();refreshStatus();}
    private void refreshStatus(){
        if(permissions==null)return;
        boolean access=ScreenAccessService.connected();
        permissions.setText("无障碍："+(access?"已连接":"未连接")+"  ·  通知访问："+
                (android.provider.Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners")!=null&&
                        android.provider.Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners").contains(getPackageName())?"已授权":"未授权"));
    }
    private boolean save(){
        try{
            String base=endpoint.getText().toString().trim();
            AgnesEngine.normalizeEndpoint(base);
            String value=model.getText().toString().trim();
            if(value.isEmpty()||value.length()>100)throw new Exception("模型名无效");
            pref().edit().putString("endpoint",base).putString("model",value).apply();
            String key=token.getText().toString().trim();
            if(!key.isEmpty()){new SecureSecretStore(this).save(key);token.setText("");}
            connectivity.setText("✓ 本地配置保存成功（连接状态尚需测试）");return true;
        }catch(Exception e){connectivity.setText("设置失败："+e.getMessage());return false;}
    }
    private GradientDrawable round(int color){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(13));return g;}
    private TextView label(String text,int size,int color){
        TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(color);
        t.setLineSpacing(dp(5),1.0f);return t;
    }
    private TextView section(String title){TextView t=label(title,16,white);
        t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(0,0,0,dp(12));return t;}
    private void space(LinearLayout parent,int dp){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(dp)));}
    private EditText input(String hint,String value,boolean secret){
        EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextSize(14);
        e.setTextColor(white);e.setHintTextColor(0xFF8EA3B6);
        if(secret)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setBackground(round(0xFF293E51));e.setPadding(dp(13),dp(12),dp(13),dp(12));
        e.setSingleLine(true);return e;
    }
    private Button button(String text,int color){
        Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextSize(13);
        b.setTextColor(white);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }
}
