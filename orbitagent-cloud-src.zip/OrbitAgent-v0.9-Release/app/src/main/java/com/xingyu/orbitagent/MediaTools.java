package com.xingyu.orbitagent;

import android.content.ComponentName;
import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

/** Metadata first: music recognition should prefer existing media metadata over audio capture. */
public final class MediaTools {
    private final Context context;
    public MediaTools(Context ctx) { context = ctx.getApplicationContext(); }
    private List<MediaController> sessions() throws Exception {
        MediaSessionManager manager = (MediaSessionManager) context.getSystemService(Context.MEDIA_SESSION_SERVICE);
        ComponentName nls = new ComponentName(context, MediaNotificationService.class);
        return manager.getActiveSessions(nls); // Requires user-enabled notification access.
    }
    public JSONObject nowPlaying() throws Exception {
        JSONArray array = new JSONArray();
        for (MediaController c : sessions()) {
            MediaMetadata meta = c.getMetadata();
            PlaybackState state = c.getPlaybackState();
            if (meta == null) continue;
            JSONObject item = new JSONObject()
                    .put("package", c.getPackageName())
                    .put("title", charValue(meta.getText(MediaMetadata.METADATA_KEY_TITLE)))
                    .put("artist", charValue(meta.getText(MediaMetadata.METADATA_KEY_ARTIST)))
                    .put("album", charValue(meta.getText(MediaMetadata.METADATA_KEY_ALBUM)))
                    .put("playing", state != null && state.getState() == PlaybackState.STATE_PLAYING);
            array.put(item);
        }
        return new JSONObject().put("success", true).put("sessions", array)
                .put("note", "仅返回 App 主动发布的媒体会话元数据；视频不一定包含歌曲信息");
    }
    public JSONObject control(String action, String packageName) throws Exception {
        if (!"play".equals(action) && !"pause".equals(action) && !"next".equals(action) && !"previous".equals(action))
            return new JSONObject().put("success", false).put("error", "不支持的控制动作");
        for (MediaController c : sessions()) {
            if (!c.getPackageName().equals(packageName)) continue;
            switch (action) {
                case "play": c.getTransportControls().play(); break;
                case "pause": c.getTransportControls().pause(); break;
                case "next": c.getTransportControls().skipToNext(); break;
                case "previous": c.getTransportControls().skipToPrevious(); break;
            }
            return new JSONObject().put("success", true).put("package", packageName).put("action", action);
        }
        return new JSONObject().put("success", false).put("error", "没有匹配的媒体会话，或通知访问权限不足");
    }
    private String charValue(CharSequence s) { return s == null ? "" : s.toString(); }
}
