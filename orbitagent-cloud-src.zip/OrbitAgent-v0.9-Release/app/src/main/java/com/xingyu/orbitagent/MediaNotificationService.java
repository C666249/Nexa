package com.xingyu.orbitagent;

import android.service.notification.NotificationListenerService;

/** Access to Android media sessions is granted by the user in Notification access. */
public final class MediaNotificationService extends NotificationListenerService { }
