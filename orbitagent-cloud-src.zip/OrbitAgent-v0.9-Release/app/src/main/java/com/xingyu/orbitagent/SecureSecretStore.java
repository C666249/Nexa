package com.xingyu.orbitagent;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypts Agnes API token with a non-exportable Android Keystore key. */
public final class SecureSecretStore {
    private static final String ALIAS = "orbit_agent_agnes_aes_v1";
    private final Context context;
    public SecureSecretStore(Context context) { this.context = context.getApplicationContext(); }
    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            generator.generateKey();
        }
        return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
    }
    public void save(String token) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] cipher = c.doFinal(token.getBytes(StandardCharsets.UTF_8));
        byte[] iv = c.getIV();
        context.getSharedPreferences("orbit_private", Context.MODE_PRIVATE).edit()
                .putString("cipher", Base64.encodeToString(cipher, Base64.NO_WRAP))
                .putString("iv", Base64.encodeToString(iv, Base64.NO_WRAP)).apply();
    }
    public String load() {
        try {
            String data = context.getSharedPreferences("orbit_private", Context.MODE_PRIVATE).getString("cipher", null);
            String nonce = context.getSharedPreferences("orbit_private", Context.MODE_PRIVATE).getString("iv", null);
            if (data == null || nonce == null) return "";
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(nonce, Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(data, Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
}
