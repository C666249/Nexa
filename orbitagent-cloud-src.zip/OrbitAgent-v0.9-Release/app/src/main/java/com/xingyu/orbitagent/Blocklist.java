package com.xingyu.orbitagent;

/** Defense in depth only; users should not grant unrestricted access to account/financial flows. */
public final class Blocklist {
    private Blocklist() { }
    static boolean sensitive(String pkg) {
        if (pkg == null || pkg.isEmpty()) return true;
        String x = pkg.toLowerCase(java.util.Locale.ROOT);
        return x.contains("bank") || x.contains("wallet") || x.contains("payment")
                || x.contains("alipay") || x.contains("finance") || x.contains("password")
                || x.contains("authenticator") || x.contains("com.android.settings") || x.contains("com.android.systemui")
                || x.contains("keyguard") || x.contains("permissioncontroller")
                || x.contains("credential") || x.contains("keystore");
    }
}
