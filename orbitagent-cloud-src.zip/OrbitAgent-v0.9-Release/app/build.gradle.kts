plugins { id("com.android.application") }
android {
    namespace = "com.xingyu.orbitagent"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.xingyu.orbitagent"
        minSdk = 30
        targetSdk = 35
        versionCode = 9
        versionName = "0.9.0-preview"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
}

tasks.matching { it.name == "assembleDebug" }.configureEach {
    doLast {
        val folder = layout.buildDirectory.dir("outputs/apk/debug").get().asFile
        folder.resolve("app-debug.apk").takeIf { it.exists() }?.copyTo(
            folder.resolve("OrbitAgent-v0.9-Debug.apk"), overwrite = true
        )
    }
}
