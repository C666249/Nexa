# 稳定跨应用代理协议（下一阶段的接入设计，尚未接入）

## 约束

- 必须保证 Stable 数据不因 Agent 升级或卸载而丢失：Agent 是外部调用方，不接管 Lunaxy/Nexa/Lumi 的持久化数据。
- Android 不允许普通 App 直接访问另一个 App 的私有目录；不能用 shareUserId 绕开沙箱。
- 推荐使用 Android Bound Service/AIDL + `signature` 权限；只有未来三项目与 Orbit 都使用**同一签名证书**时才适用。
- 如果现有 Stable 使用不同签名，不要要求用户卸载 Stable 改签名。改用用户授权的 ActivityResult/ContentProvider 文件选择器或显式 Intent 深链接来桥接，降低无感能力但保护数据；生产版再使用一次性配对 Token + 调用方签名检查。
- 所有 destructive / externally visible action 需要用户二次确认，如删除歌单、删除笔记、覆盖数据、发消息。

## 统一消息格式（示例）

请求：
```json
{
  "request_id":"b15d9f...",
  "namespace":"lunaxy",
  "tool":"search_music_catalog",
  "args":{"query":"周杰伦 我不配","limit":5},
  "dry_run":false,
  "requested_at":1720000000000
}
```

响应：
```json
{
  "request_id":"b15d9f...",
  "success":true,
  "data":{"tracks":[]},
  "source_app":"com.xingyu.music",
  "duration_ms":31
}
```

字段与上面例子只是协议设计说明，非目前代码中已注册的跨 App 工具。

## 推荐权限模式

- READ：可配置为“每次询问 / 本次会话允许”；OCR、截图及私密内容必须明确授权，且需支持一键撤回。
- ACTION：默认每次询问；播放音乐等低风险动作可白名单自动允许。
- DESTRUCTIVE：必须显示对象与影响后由用户确认。
- EXTERNAL：联网或对外发送不可静默执行。

## 顺序与安全

Agent 中央工具层统一记录 request_id、工具名、完成状态、是否需要用户确认，但不写入用户私人文本或截图。跨应用结果用 `source_app` 指明来源；幂等 request_id 避免网络重试导致重复创建。
